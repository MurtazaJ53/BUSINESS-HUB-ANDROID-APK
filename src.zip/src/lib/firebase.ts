import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { initializeFirestore, persistentLocalCache, persistentMultipleTabManager } from 'firebase/firestore';
import { getFunctions } from "firebase/functions";
import { initializeAppCheck, ReCaptchaV3Provider } from "firebase/app-check";

// New Business Hub Pro Project Configuration
const firebaseConfig = {
  apiKey: "AIzaSyDHSGEIdDt1m-Iu3swFoKlwNA28Xck41fM",
  authDomain: "business-hub-pro.firebaseapp.com",
  projectId: "business-hub-pro",
  storageBucket: "business-hub-pro.firebasestorage.app",
  messagingSenderId: "631267912572",
  appId: "1:631267912572:web:663c0732dc25fd714f12f9",
  measurementId: "G-MKZVQ6EYZT"
};

const app = initializeApp(firebaseConfig);

// Initialize App Check (client-side only, safe for native mobile)
if (typeof window !== 'undefined') {
  const siteKey = import.meta.env.VITE_RECAPTCHA_SITE_KEY;
  if (siteKey && siteKey !== 'undefined') {
    try {
      initializeAppCheck(app, {
        provider: new ReCaptchaV3Provider(siteKey),
        isTokenAutoRefreshEnabled: true
      });
    } catch (err) {
      console.warn("App Check failed to initialize (Recaptcha might not work on native mobile):", err);
    }
  } else {
    console.warn("App Check site key missing. Functions will require bypass or upgrade to Blaze.");
  }
}

export const auth = getAuth(app);
export const db = initializeFirestore(app, { 
  localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }) 
});
export const functions = getFunctions(app, 'us-central1');
export const googleProvider = new GoogleAuthProvider();
